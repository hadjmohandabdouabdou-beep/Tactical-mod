# TacticalRange — Minecraft 1.21.1 / NeoForge source

This is **source code**, not a compiled Minecraft mod. Built from Claude's supplied `TacticalRange-source-step1.zip` with range targets, a weapon cabinet, and GitHub build instructions added.

## Features
- 50 fictional weapon items with server-side hitscan, damage, ammunition, reload and cooldown.
- Paper and steel shooting target blocks; hit counter displays 1–15 in action bar.
- Weapon cabinet block: holds 9 weapons including their loaded ammo; right-click with gun to store, empty hand to retrieve. Breaking the cabinet drops its stored items.
- 7 ammunition types; Creative tabs for weapons, ammo, and range furniture.

**Limitations:** weapon art is placeholder 16×16 icon art; automatic/burst fire rates are catalogued but each right-click currently triggers one shot. No custom animations, scopes, full cabinet GUI or mobile performance testing. Source needs a successful Gradle build and Minecraft runtime test before it can be claimed playable.

## Build via GitHub Actions (can be done from Android)
1. Create an **empty** repository at https://github.com/new (e.g. TacticalRange).
2. Unzip this distribution and **upload the files inside the `TacticalRange/` folder into the repository root**. The `.github/workflows/build.yml` file must remain in its `.github/workflows` directory.
3. Open your repository's **Actions** tab. Allow workflows if GitHub asks. Select **Build NeoForge Mod JAR** → **Run workflow** (or the first push triggers it).
4. Wait for the job to finish, open the successful run, and under **Artifacts** download `TacticalRange-NeoForge-1.21.1-JAR`. Extract the downloaded artifact ZIP to get the genuine `.jar`.
5. Put the `.jar` into Minecraft **Java 1.21.1**'s `mods` directory with the matching **NeoForge 21.1.x** runtime.

If the build fails, open the red workflow run and read the **Compile and package** step for the exact compiler error. The `.jar` cannot be guaranteed until this step passes.

## Local build
- Java 21, Internet access to Gradle and NeoForge repositories, Gradle 8.10.2.
- `gradle clean build` then check `build/libs/`.

## Playing
- Creative inventory: TacticalRange weapons, ammunition, and Range & Storage tabs.
- Gun right-click: fire once. Shift + right-click: reload from inventory ammo.
- Targets: place and shoot; count shown in action bar.
- Cabinet: right-click it with a gun to store; use empty hand to retrieve latest stored gun. Stores 9 guns; inventory saved in block entity NBT.
