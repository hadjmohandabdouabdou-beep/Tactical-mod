package com.tacticalrange.ammo;
import net.minecraft.world.item.Item;
public class AmmoItem extends Item {
  public final AmmoType type;
  public AmmoItem(AmmoType type, Properties props) { super(props); this.type = type; }
}
