package com.tacticalrange.ammo;
public enum AmmoType { PISTOL, SMG, RIFLE, HEAVY_RIFLE, SHELL, SNIPER, SPECIAL }
