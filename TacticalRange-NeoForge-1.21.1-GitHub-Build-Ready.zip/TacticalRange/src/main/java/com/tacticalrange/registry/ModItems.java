package com.tacticalrange.registry;
import com.tacticalrange.ammo.*;
import com.tacticalrange.weapon.*;
import java.util.*;
import net.neoforged.neoforge.registries.DeferredItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
public final class ModItems {
  public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("tacticalrange");
  public static final List<DeferredHolder<Item, ? extends Item>> WEAPONS = new ArrayList<>(), AMMO = new ArrayList<>();
  public static final DeferredItem<BlockItem> PAPER_TARGET = ITEMS.registerSimpleBlockItem(ModBlocks.PAPER_TARGET);
  public static final DeferredItem<BlockItem> STEEL_TARGET = ITEMS.registerSimpleBlockItem(ModBlocks.STEEL_TARGET);
  public static final DeferredItem<BlockItem> WEAPON_CABINET = ITEMS.registerSimpleBlockItem(ModBlocks.WEAPON_CABINET);
  static {
    for (WeaponDef d : Weapons.ALL) WEAPONS.add(ITEMS.register(d.id(), () -> new WeaponItem(d, new Item.Properties())));
    for (AmmoType t : AmmoType.values()) AMMO.add(ITEMS.register("ammo_" + t.name().toLowerCase(), () -> new AmmoItem(t, new Item.Properties().stacksTo(64))));
  }
  private ModItems() {}
}
