package com.tacticalrange.registry;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
public final class ModComponents {
  public static final DeferredRegister.DataComponents COMPONENTS = DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, "tacticalrange");
  /** Rounds currently loaded in the weapon. Survives inventory/cabinet storage. */
  public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> AMMO =
      COMPONENTS.registerComponentType("ammo", b -> b.persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT));
  private ModComponents() {}
}
