package com.tacticalrange.registry;

import com.tacticalrange.block.WeaponCabinetBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
        DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "tacticalrange");
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WeaponCabinetBlockEntity>> WEAPON_CABINET =
        BLOCK_ENTITIES.register("weapon_cabinet", () -> BlockEntityType.Builder.of(
            WeaponCabinetBlockEntity::new, ModBlocks.WEAPON_CABINET.get()).build(null));
    private ModBlockEntities() {}
}
