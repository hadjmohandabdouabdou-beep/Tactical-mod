package com.tacticalrange.registry;

import com.tacticalrange.block.ShootingTargetBlock;
import com.tacticalrange.block.WeaponCabinetBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("tacticalrange");
    public static final DeferredBlock<ShootingTargetBlock> PAPER_TARGET = BLOCKS.registerBlock(
        "paper_target", ShootingTargetBlock::new, BlockBehaviour.Properties.of().strength(1.0f));
    public static final DeferredBlock<ShootingTargetBlock> STEEL_TARGET = BLOCKS.registerBlock(
        "steel_target", ShootingTargetBlock::new, BlockBehaviour.Properties.of().strength(3.0f));
    public static final DeferredBlock<WeaponCabinetBlock> WEAPON_CABINET = BLOCKS.registerBlock(
        "weapon_cabinet", WeaponCabinetBlock::new, BlockBehaviour.Properties.of().strength(2.5f));
    private ModBlocks() {}
}
