package com.tacticalrange.registry;
import com.tacticalrange.weapon.WeaponItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
public final class ModTabs {
  public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "tacticalrange");
  public static final DeferredHolder<CreativeModeTab, CreativeModeTab> WEAPONS = TABS.register("weapons", () -> CreativeModeTab.builder()
      .title(Component.translatable("itemGroup.tacticalrange.weapons")).icon(() -> new ItemStack(ModItems.WEAPONS.get(0).get()))
      .displayItems((p, o) -> ModItems.WEAPONS.forEach(h -> {
        ItemStack s = new ItemStack(h.get());
        if (h.get() instanceof WeaponItem w) s.set(ModComponents.AMMO.get(), w.def.magSize());
        o.accept(s);
      })).build());
  public static final DeferredHolder<CreativeModeTab, CreativeModeTab> AMMO = TABS.register("ammo", () -> CreativeModeTab.builder()
      .title(Component.translatable("itemGroup.tacticalrange.ammo")).icon(() -> new ItemStack(ModItems.AMMO.get(0).get()))
      .displayItems((p, o) -> ModItems.AMMO.forEach(h -> o.accept(h.get()))).build());
  public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RANGE = TABS.register("range", () -> CreativeModeTab.builder()
      .title(Component.translatable("itemGroup.tacticalrange.range"))
      .icon(() -> new ItemStack(ModItems.PAPER_TARGET.get()))
      .displayItems((p, o) -> {
        o.accept(ModItems.PAPER_TARGET.get());
        o.accept(ModItems.STEEL_TARGET.get());
        o.accept(ModItems.WEAPON_CABINET.get());
      }).build());
  private ModTabs() {}
}
