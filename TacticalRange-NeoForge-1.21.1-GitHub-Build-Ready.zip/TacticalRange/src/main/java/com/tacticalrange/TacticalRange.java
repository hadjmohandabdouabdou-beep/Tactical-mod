package com.tacticalrange;
import com.tacticalrange.config.ServerConfig;
import com.tacticalrange.registry.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
@Mod("tacticalrange")
public class TacticalRange {
  public TacticalRange(IEventBus bus, ModContainer container) {
    ModComponents.COMPONENTS.register(bus);
    ModBlocks.BLOCKS.register(bus);
    ModBlockEntities.BLOCK_ENTITIES.register(bus);
    ModItems.ITEMS.register(bus);
    ModTabs.TABS.register(bus);
    container.registerConfig(ModConfig.Type.SERVER, ServerConfig.SPEC);
  }
}
