package com.tacticalrange.block;

import com.tacticalrange.registry.ModBlockEntities;
import com.tacticalrange.weapon.WeaponItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.Containers;

/** Persistent 9-slot weapon rack. Insert with gun in hand; retrieve with empty hand. */
public final class WeaponCabinetBlockEntity extends BlockEntity {
    private final NonNullList<ItemStack> inventory = NonNullList.withSize(9, ItemStack.EMPTY);

    public WeaponCabinetBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WEAPON_CABINET.get(), pos, state);
    }

    public int count() {
        int count = 0;
        for (ItemStack item : inventory) if (!item.isEmpty()) count++;
        return count;
    }

    public boolean insert(ItemStack inHand, boolean creative) {
        if (!(inHand.getItem() instanceof WeaponItem)) return false;
        for (int i = 0; i < inventory.size(); i++) {
            if (inventory.get(i).isEmpty()) {
                inventory.set(i, inHand.copyWithCount(1));
                if (!creative) inHand.shrink(1);
                update();
                return true;
            }
        }
        return false;
    }

    public ItemStack take() {
        for (int i = inventory.size() - 1; i >= 0; i--) {
            if (!inventory.get(i).isEmpty()) {
                ItemStack extracted = inventory.get(i);
                inventory.set(i, ItemStack.EMPTY);
                update();
                return extracted;
            }
        }
        return ItemStack.EMPTY;
    }

    public void dropContents(Level level, BlockPos pos) {
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.get(i);
            if (!stack.isEmpty()) {
                Containers.dropItemStack(level, pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5, stack);
                inventory.set(i, ItemStack.EMPTY);
            }
        }
        update();
    }

    private void update() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int i = 0; i < inventory.size(); i++) inventory.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, inventory, registries);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, inventory, registries);
    }
}
