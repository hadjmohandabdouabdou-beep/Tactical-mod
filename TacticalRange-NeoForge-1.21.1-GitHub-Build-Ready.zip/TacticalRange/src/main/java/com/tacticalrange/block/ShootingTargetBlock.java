package com.tacticalrange.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Test-range target. Consecutive hits accumulate up to 15; then the counter wraps. */
public final class ShootingTargetBlock extends Block {
    public static final IntegerProperty HITS = IntegerProperty.create("hits", 0, 15);

    public ShootingTargetBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(HITS, 0));
    }
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HITS);
    }
    public void registerHit(Level level, BlockPos pos, Player shooter) {
        if (level.isClientSide) return;
        BlockState state = level.getBlockState(pos);
        if (!state.is(this)) return;
        int hits = state.getValue(HITS) + 1;
        if (hits > 15) hits = 1;
        level.setBlock(pos, state.setValue(HITS, hits), Block.UPDATE_CLIENTS);
        level.playSound(null, pos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 0.75f, 0.85f + hits * 0.04f);
        shooter.displayClientMessage(Component.literal("Target hits: " + hits + "/15"), true);
    }
}
