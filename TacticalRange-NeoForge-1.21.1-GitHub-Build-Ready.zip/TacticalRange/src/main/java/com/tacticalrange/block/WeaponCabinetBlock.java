package com.tacticalrange.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import com.tacticalrange.weapon.WeaponItem;

/** Minimal functional cabinet: stores up to nine weapons, preserving loaded ammunition. */
public final class WeaponCabinetBlock extends BaseEntityBlock {
    public WeaponCabinetBlock(Properties props) { super(props); }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WeaponCabinetBlockEntity(pos, state);
    }
    @Override
    protected RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
            Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(held.getItem() instanceof WeaponItem)) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof WeaponCabinetBlockEntity cabinet) {
            if (cabinet.insert(held, player.getAbilities().instabuild)) {
                level.playSound(null, pos, SoundEvents.BARREL_CLOSE, SoundSource.BLOCKS, 0.8f, 1.2f);
            } else player.displayClientMessage(Component.literal("Weapon cabinet full (9/9)"), true);
        }
        return ItemInteractionResult.SUCCESS;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
            Player player, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof WeaponCabinetBlockEntity cabinet) {
            ItemStack taken = cabinet.take();
            if (!taken.isEmpty()) {
                player.getInventory().placeItemBackInInventory(taken);
                level.playSound(null, pos, SoundEvents.BARREL_OPEN, SoundSource.BLOCKS, 0.8f, 1.1f);
            } else player.displayClientMessage(Component.literal("Weapon cabinet empty"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected void onRemove(BlockState oldState, Level level, BlockPos pos,
            BlockState newState, boolean movedByPiston) {
        if (!oldState.is(newState.getBlock()) && !level.isClientSide &&
                level.getBlockEntity(pos) instanceof WeaponCabinetBlockEntity cabinet) {
            cabinet.dropContents(level, pos);
        }
        super.onRemove(oldState, level, pos, newState, movedByPiston);
    }
}
