package com.tacticalrange.weapon;
import com.tacticalrange.ammo.AmmoItem;
import com.tacticalrange.block.ShootingTargetBlock;
import com.tacticalrange.config.ServerConfig;
import com.tacticalrange.registry.ModComponents;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;
public class WeaponItem extends Item {
  public final WeaponDef def;
  public WeaponItem(WeaponDef def, Properties props) { super(props.stacksTo(1)); this.def = def; }
  public static int ammo(ItemStack s) { return s.getOrDefault(ModComponents.AMMO.get(), 0); }
  @Override public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
    ItemStack s = p.getItemInHand(hand);
    if (level.isClientSide) return InteractionResultHolder.consume(s);
    if (p.isShiftKeyDown()) { reload(p, s); return InteractionResultHolder.success(s); }
    int a = ammo(s);
    if (a <= 0) { level.playSound(null, p.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.6f, 1.6f); return InteractionResultHolder.fail(s); }
    s.set(ModComponents.AMMO.get(), a - 1);
    p.getCooldowns().addCooldown(this, def.cooldownTicks());
    fire(level, p);
    return InteractionResultHolder.success(s);
  }
  private void fire(Level level, Player p) {
    Vec3 eye = p.getEyePosition();
    double sp = 0.0175 * def.spread() * (p.isSprinting() ? 1.5 : 1.0);
    Vec3 dir = p.getLookAngle().add(p.getRandom().triangle(0, sp), p.getRandom().triangle(0, sp), p.getRandom().triangle(0, sp)).normalize();
    Vec3 end = eye.add(dir.scale(def.range()));
    BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
    if (bh.getType() != HitResult.Type.MISS) end = bh.getLocation();
    EntityHitResult eh = ProjectileUtil.getEntityHitResult(level, p, eye, end,
        p.getBoundingBox().expandTowards(dir.scale(def.range())).inflate(1), e -> !e.isSpectator() && e.isPickable());
    if (eh == null && bh.getType() == HitResult.Type.BLOCK && level.getBlockState(bh.getBlockPos()).getBlock() instanceof ShootingTargetBlock target) {
      target.registerHit(level, bh.getBlockPos(), p);
    }
    if (eh != null) {
      Entity t = eh.getEntity();
      double dist = eye.distanceTo(eh.getLocation());
      float dmg = (float) (def.damage() * ServerConfig.DAMAGE_MULT.get() * (1 - 0.5 * dist / def.range()));
      boolean head = eh.getLocation().y > t.getEyeY() - 0.25;
      t.hurt(level.damageSources().playerAttack(p), head ? dmg * 2f : dmg);
    }
    level.playSound(null, p.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1f, 1.4f - def.weight() * 0.3f);
    p.setXRot(p.getXRot() - def.recoil() * 0.3f); // placeholder; smooth client camera recoil comes in the client step
  }
  private void reload(Player p, ItemStack s) {
    int need = def.magSize() - ammo(s);
    if (need <= 0) return;
    boolean inf = ServerConfig.INFINITE_AMMO.get();
    int got = 0;
    for (ItemStack inv : p.getInventory().items) {
      if (got >= need) break;
      if (inv.getItem() instanceof AmmoItem ai && ai.type == def.ammo()) {
        int take = inf ? need - got : Math.min(inv.getCount(), need - got);
        got += take; if (!inf) inv.shrink(take);
      }
    }
    if (got == 0) { p.displayClientMessage(Component.translatable("message.tacticalrange.no_ammo"), true); return; }
    s.set(ModComponents.AMMO.get(), ammo(s) + got);
    p.getCooldowns().addCooldown(this, def.reloadTicks());
    p.level().playSound(null, p.blockPosition(), SoundEvents.CROSSBOW_LOADING_END.value(), SoundSource.PLAYERS, 1f, 1f);
    p.displayClientMessage(Component.translatable("message.tacticalrange.reloaded"), true);
  }
  @Override public void appendHoverText(ItemStack s, TooltipContext c, List<Component> t, TooltipFlag f) {
    t.add(Component.literal(def.category() + " | " + def.mode() + " | " + def.ammo() + " ammo"));
    t.add(Component.literal("Ammo " + ammo(s) + "/" + def.magSize() + "  Dmg " + def.damage() + "  RPM " + def.rpm()));
    t.add(Component.literal("Sneak + right-click to reload"));
  }
}
