package com.tacticalrange.weapon;
public enum WeaponCategory { PISTOL, SMG, ASSAULT_RIFLE, BATTLE_RIFLE, SHOTGUN, SNIPER, LMG, SPECIAL }
