package com.tacticalrange.weapon;
import com.tacticalrange.ammo.AmmoType;
/** Immutable weapon stats. recoil/spread in degrees, range in blocks, weight 0.4..2 (higher = slower ADS). */
public record WeaponDef(WeaponCategory category, String id, String name, AmmoType ammo, FireMode mode,
    float damage, int rpm, int magSize, int reloadTicks, float recoil, float spread, int range, float weight, int adsTicks) {
  public int cooldownTicks() { return Math.max(1, Math.round(1200f / rpm)); }
}
