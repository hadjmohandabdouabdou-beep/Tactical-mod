package com.tacticalrange.weapon;
public enum FireMode { SEMI, AUTO, BURST, PUMP, BOLT }
