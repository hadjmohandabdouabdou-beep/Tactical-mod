package com.tacticalrange.config;
import net.neoforged.neoforge.common.ModConfigSpec;
public final class ServerConfig {
  public static final ModConfigSpec SPEC;
  public static final ModConfigSpec.DoubleValue DAMAGE_MULT;
  public static final ModConfigSpec.BooleanValue INFINITE_AMMO;
  static {
    ModConfigSpec.Builder b = new ModConfigSpec.Builder();
    DAMAGE_MULT = b.comment("Global weapon damage multiplier").defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
    INFINITE_AMMO = b.comment("Do not consume ammo items when reloading").define("infiniteAmmo", false);
    SPEC = b.build();
  }
  private ServerConfig() {}
}
